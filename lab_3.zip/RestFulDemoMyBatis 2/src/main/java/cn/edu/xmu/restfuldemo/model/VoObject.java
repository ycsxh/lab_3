package cn.edu.xmu.restfuldemo.model;

/**
 * @author Ming Qiu
 **/
public interface VoObject {

    /**
     * 创建Vo对象
     * @return Vo对象
     */
    public Object createVo();
}
